import Heading from "./components/Heading"
import P1 from "./components/P1"
import {BrowserRouter, Routes, Route} from "react-router-dom"
import Layout from "./components/Layout"
import Contact from "./components/Contact"
import Blank from "./components/Blank"


function App() {
  return (
    <><BrowserRouter>
     <Routes>
      <Route path = "/" element={<Layout />}>
        <Route index element={<Counter />}></Route>
        <Route path = "/Blank" element={<Blank/>}></Route>
        <Route path = "/Contact" element={<Content />}></Route>
      </Route>
     </Routes>
     
     
     </BrowserRouter>
    </>
  )
}




export default App
