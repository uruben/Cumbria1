import React from 'react'

export default function P1({children}) {
  return (
    <p>
        {children}
    </p>
  )
}
