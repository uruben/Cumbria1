import React from 'react'
import {Link, Outlet} from "react-router-dom"


export default function Layout() {
    return (
        <>
         <header className="bg-black p-4 w-full text-white">
            <link to="/Blank">Blank</link>
            <link to="/Contact">Contact</link>

         </header>
        

         <div>
            {/* page content */}
            <Outlet />
         </div>
        
        
        
        
        
        
        
        </>
    )
}